{
  "status": 1,
    "message": "首页产品介绍",
      "data": {
    "goodsInfo": [
      {
        "g_id": 1,
        "g_name": "三磷酸醛苷双磷酸酶Apyrase",
        "g_jian": "三磷酸醛苷双磷酸酶Apyrase商品简介",
        "g_content": "商品内容",
        "g_quality": "一年",
        "g_condition": "-20°C,避免反复冻融",
        "gp_id": 0,
        "g_createtime": "1515999467",
        "gc_id": 1,
        "gc_title": "商品分类1",
        "gc_pid": 0,
        "gc_createtime": "1515986485",
        "gc_status": 0,
        "gc_order": 1,
        "goodsNum": [
          {
            "n_id": 1,
            "n_number": "E0001-01",
            "n_spec": "50units",
            "n_price": "552",
            "n_case": 5,
            "n_goods_id": 1
          },
          {
            "n_id": 2,
            "n_number": "E0001-02",
            "n_spec": "100units",
            "n_price": "995",
            "n_case": 6,
            "n_goods_id": 1
          },
          {
            "n_id": 3,
            "n_number": "E0001-03",
            "n_spec": "200units",
            "n_price": "1791",
            "n_case": 0,
            "n_goods_id": 1
          },
          {
            "n_id": 4,
            "n_number": "E0001-OEM",
            "n_spec": "",
            "n_price": "55",
            "n_case": 0,
            "n_goods_id": 1
          }
        ],
        "goodsImg": [
          {
            "gp_id": 1,
            "gp_photo": "/uploads/2018-01-18/20180118153640191.jpg",
            "gp_thum": "uploads/2018-01-18/thum_20180118153640191.jpg",
            "gp_small": "uploads/2018-01-18/small_20180118153640191.jpg",
            "g_id": 1,
            "gp_createtime": "1516261000"
          },
          {
            "gp_id": 2,
            "gp_photo": "uploads/2018-01-18/20180118153640191.jpg",
            "gp_thum": "uploads/2018-01-18/thum_20180118153640191.jpg",
            "gp_small": "uploads/2018-01-18/small_20180118153640191.jpg",
            "g_id": 1,
            "gp_createtime": "1516261000"
          },
          {
            "gp_id": 3,
            "gp_photo": "uploads/2018-01-18/20180118153640191.jpg",
            "gp_thum": "uploads/2018-01-18/thum_20180118153640191.jpg",
            "gp_small": "uploads/2018-01-18/small_20180118153640191.jpg",
            "g_id": 1,
            "gp_createtime": "1516261000"
          },
          {
            "gp_id": 4,
            "gp_photo": "uploads/2018-01-18/20180118153640191.jpg",
            "gp_thum": "uploads/2018-01-18/thum_20180118153640191.jpg",
            "gp_small": "uploads/2018-01-18/small_20180118153640191.jpg",
            "g_id": 1,
            "gp_createtime": "1516261000"
          }
        ]
      },
      {
        "g_id": 2,
        "g_name": "傻掉了静安",
        "g_jian": "萨达撒出V型",
        "g_content": "<p>阿斯顿撒操行送东方闪电</p>",
        "g_quality": null,
        "g_condition": null,
        "gp_id": 0,
        "g_createtime": "1516073223",
        "gc_id": 1,
        "gc_title": "商品分类1",
        "gc_pid": 0,
        "gc_createtime": "1515986485",
        "gc_status": 0,
        "gc_order": 1,
        "goodsNum": [],
        "goodsImg": []
      }
    ]
  }
}