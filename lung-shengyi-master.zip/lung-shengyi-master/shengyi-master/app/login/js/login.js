/*
 * @Author: huangzexia
 * @Date:   2017-01-11 15:49:29
 * @Last Modified by:   huangzexia
 * @Last Modified time: 2017-01-11 15:49:52
 */

console.log(67)
let btn = document.getElementById('btn');
btn.addEventListener('click', function() {
    openWindow('/foods/');
})

let a = 13
console.log(a)